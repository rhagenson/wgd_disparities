`impact-505.txt` is a local copy of the IMPACT-505 geneset

`MSK-WGD.csv` contains the WGD calls per-patient for MSK-MET

`regionalLN.csv` is supplemental data from 10.1016/j.cell.2022.01.003

`msk-met-cell2022-ancestry.tsv` provided by Kanika Arora, following the method from Arora, et al. (2022)

`MSK_AS.csv` is the arm-level aneuploidies for BLACK and WHTIE patients along with the overall aneuploidy burden score